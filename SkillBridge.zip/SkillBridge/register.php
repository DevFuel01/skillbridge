<?php
require_once 'db.php';
require_once 'includes/functions.php'; // For logging
require_once 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = 'student'; // Force student role for public registration
    $age_range = $_POST['age_range'];
    $learning_level = $_POST['learning_level'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered.";
        } else {
            // Register user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, age_range, learning_level, role) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $hashed_password, $age_range, $learning_level, $role])) {
                $user_id = $pdo->lastInsertId();

                // Prevent session fixation
                session_regenerate_id(true);

                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $name;

                log_activity($pdo, $user_id, 'Registration', 'New user registered');

                echo "<script>window.location.href='dashboard.php';</script>";
                exit;
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<div class="container" style="max-width: 500px;">
    <div class="card">
        <h2 class="text-center mb-4">Create Account</h2>

        <?php if ($error): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required placeholder="John Doe">
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required placeholder="john@example.com">
            </div>

            <div class="form-group">
                <label for="age_range">Age Range</label>
                <select id="age_range" name="age_range" class="form-control" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius);" required>
                    <option value="Under 18">Under 18</option>
                    <option value="18-24" selected>18-24</option>
                    <option value="25-34">25-34</option>
                    <option value="35-44">35-44</option>
                    <option value="45+">45+</option>
                </select>
            </div>

            <div class="form-group">
                <label for="learning_level">Current Skill Level</label>
                <select id="learning_level" name="learning_level" class="form-control" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius);" required>
                    <option value="Beginner" selected>Beginner (I'm starting fresh)</option>
                    <option value="Intermediate">Intermediate (I know the basics)</option>
                    <option value="Advanced">Advanced (I want to master skills)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="******">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required placeholder="******">
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="padding: 0.75rem;">Register</button>
        </form>
        <p class="text-center mt-4">
            Already have an account? <a href="login.php">Login here</a>
        </p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>