<?php
require_once 'db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS community_suggestions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        suggestion TEXT NOT NULL,
        status ENUM('pending', 'approved') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )";

    $pdo->exec($sql);
    echo "Table 'community_suggestions' created successfully.\n";
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
