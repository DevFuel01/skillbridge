<?php
require_once 'db.php';

try {
    echo "Starting categories migration...<br>";

    // Add category column
    $stmt = $pdo->query("SHOW COLUMNS FROM lessons LIKE 'category'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE lessons ADD COLUMN category VARCHAR(255) DEFAULT 'Other' AFTER difficulty");
        echo "Added 'category' column.<br>";
    } else {
        echo "'category' column already exists.<br>";
    }

    echo "Migration completed successfully.";
} catch (PDOException $e) {
    die("Migration failed: " . $e->getMessage());
}
