<?php
require_once 'db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS activity_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        action VARCHAR(255) NOT NULL,
        details TEXT NULL,
        ip_address VARCHAR(45) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )";

    $pdo->exec($sql);
    echo "Table 'activity_log' created successfully.\n";
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
