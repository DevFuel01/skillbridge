<?php
require_once 'db.php';
require_once 'includes/header.php';

// Check auth
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: lessons.php");
    exit;
}

$lesson_id = $_GET['id'];

// Fetch Lesson & Quiz
$stmt = $pdo->prepare("
    SELECT l.title, q.questions_json 
    FROM lessons l 
    JOIN quizzes q ON l.id = q.lesson_id 
    WHERE l.id = ?
");
$stmt->execute([$lesson_id]);
$data = $stmt->fetch();

if (!$data) {
    echo "<div class='container'><h2>No quiz available for this lesson.</h2><a href='lesson.php?id=$lesson_id'>Back to Lesson</a></div>";
    require_once 'includes/footer.php';
    exit;
}

$questions = json_decode($data['questions_json'], true);
?>

<div class="container" style="max-width: 600px;">
    <h1 class="mb-4">Quiz: <?php echo htmlspecialchars($data['title']); ?></h1>

    <div id="quiz-container" class="card">
        <div id="question-view">
            <div style="display: flex; justify-content: space-between; color: var(--text-muted); margin-bottom: 1rem;">
                <span id="question-counter">Question 1 of <?php echo count($questions); ?></span>
                <span id="score-display">Score: 0</span>
            </div>

            <h3 id="question-text" class="mb-4">Loading...</h3>

            <div id="options-container" style="display: flex; flex-direction: column; gap: 0.75rem;">
                <!-- Options rendered here -->
            </div>
        </div>

        <div id="result-view" style="display: none; text-align: center;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">🎉</div>
            <h2 class="mb-4">Quiz Completed!</h2>
            <p style="font-size: 1.5rem; margin-bottom: 2rem;">Your Score: <span id="final-score" style="font-weight: 700; color: var(--primary-color);">0</span>%</p>
            <div style="display: flex; gap: 1rem; justify-content: center;">
                <a href="lesson.php?id=<?php echo $lesson_id; ?>" class="btn btn-outline">Review Lesson</a>
                <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
            </div>
        </div>
    </div>
</div>

<script>
    let questions = <?php echo json_encode($questions); ?>;
    const lessonId = <?php echo $lesson_id; ?>;

    // Fisher-Yates Shuffle
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    // Randomize questions
    shuffleArray(questions);

    let currentQuestionIndex = 0;
    let score = 0;

    const questionText = document.getElementById('question-text');
    const optionsContainer = document.getElementById('options-container');
    const questionCounter = document.getElementById('question-counter');
    const viewQuestion = document.getElementById('question-view');
    const viewResult = document.getElementById('result-view');
    const finalScore = document.getElementById('final-score');

    function loadQuestion() {
        const q = questions[currentQuestionIndex];
        questionText.textContent = q.question;
        questionCounter.textContent = `Question ${currentQuestionIndex + 1} of ${questions.length}`;
        optionsContainer.innerHTML = '';

        q.options.forEach((opt, index) => {
            const btn = document.createElement('button');
            btn.className = 'btn btn-outline btn-block';
            btn.style.textAlign = 'left';
            btn.textContent = opt;
            btn.onclick = () => selectAnswer(index);
            optionsContainer.appendChild(btn);
        });
    }

    function selectAnswer(selectedIndex) {
        const q = questions[currentQuestionIndex];
        const buttons = optionsContainer.children;

        // Show correct/incorrect
        if (selectedIndex === q.correct) {
            buttons[selectedIndex].style.backgroundColor = '#d1fae5'; // green-100
            buttons[selectedIndex].style.borderColor = '#10b981';
            score++;
        } else {
            buttons[selectedIndex].style.backgroundColor = '#fee2e2'; // red-100
            buttons[selectedIndex].style.borderColor = '#ef4444';
            // Show correct answer
            buttons[q.correct].style.backgroundColor = '#d1fae5';
            buttons[q.correct].style.borderColor = '#10b981';
        }

        // Disable all
        Array.from(buttons).forEach(b => b.disabled = true);

        setTimeout(() => {
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.length) {
                loadQuestion();
            } else {
                showResults();
            }
        }, 1500);
    }

    function showResults() {
        const percentage = Math.round((score / questions.length) * 100);
        viewQuestion.style.display = 'none';
        viewResult.style.display = 'block';
        finalScore.textContent = percentage;

        // Save to DB
        fetch('api/submit_quiz.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                lesson_id: lessonId,
                score: percentage
            })
        });
    }

    // Start
    loadQuestion();
</script>

<?php require_once 'includes/footer.php'; ?>