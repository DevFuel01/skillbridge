# SkillBridge Deployment Instructions

## Prerequisites
- **XAMPP** (or any LAMP/WAMP stack) with PHP 8.0+ and MySQL.

## Installation Steps
1. **Copy Files**: Ensure the `SkillBridge` folder is located in your `htdocs` directory (e.g., `C:\xampp\htdocs\SkillBridge`).
2. **Start Servers**: Open XAMPP Control Panel and start **Apache** and **MySQL**.
3. **Setup Database**:
   - Open a browser and go to `http://localhost/phpmyadmin`.
   - Create a new database named `skillbridge`.
   - Import the `database.sql` file located in the `SkillBridge` project folder.
   - *Alternatively*, copy the contents of `database.sql` and run it in the SQL tab of phpMyadmin.
4. **Access the App**:
   - Open your browser and navigate to `http://localhost/SkillBridge`.

## Accounts
- You can register a new account on the home page.
- Or use the sample database if populated.

## Offline Mode Testing
- Open Developer Tools (F12).
- Go to the **Application** tab -> **Service Workers**.
- Ensure the Service Worker is registered.
- Go to the **Network** tab and select **Offline**.
- Refresh the page or navigate to visited pages to verify they load from cache.
