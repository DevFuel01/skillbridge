<?php require_once 'includes/header.php'; ?>

<section class="hero text-center" style="padding: 4rem 1rem;">
    <h1 style="margin-bottom: 1rem; color: var(--primary-color); font-size: 3.5rem;">Master Digital Skills,<br>Anytime, Anywhere.</h1>
    <p style="font-size: 1.25rem; color: var(--text-muted); max-width: 600px; margin: 0 auto 2rem;">
        Empowering students in low-resource communities with offline-first learning.
        Start your journey to a brighter future today.
    </p>
    <div style="display: flex; gap: 1rem; justify-content: center;">
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="lessons.php" class="btn btn-primary" style="padding: 1rem 2.5rem; font-size: 1.1rem;">Continue Learning</a>
        <?php else: ?>
            <a href="register.php" class="btn btn-primary" style="padding: 1rem 2.5rem; font-size: 1.1rem;">Get Started</a>
            <a href="lessons.php" class="btn btn-outline" style="padding: 1rem 2.5rem; font-size: 1.1rem;">Browse Lessons</a>
        <?php endif; ?>
    </div>
</section>

<section class="features container" style="padding: 4rem 1.5rem;">
    <h2 class="text-center mb-4" style="font-size: 2.5rem;">Why SkillBridge?</h2>
    <div class="grid">
        <div class="card text-center" style="padding: 2rem;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">⚡</div>
            <h3>Offline Access</h3>
            <p style="color: var(--text-muted);">Download lessons automatically and learn without an internet connection.</p>
        </div>
        <div class="card text-center" style="padding: 2rem;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🧠</div>
            <h3>Interactive Quizzes</h3>
            <p style="color: var(--text-muted);">Test your knowledge instantly and track your progress over time.</p>
        </div>
        <div class="card text-center" style="padding: 2rem;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">📊</div>
            <h3>Track Progress</h3>
            <p style="color: var(--text-muted);">Visualize your learning journey with your personal dashboard.</p>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>