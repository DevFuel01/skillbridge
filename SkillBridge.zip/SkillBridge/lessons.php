<?php
require_once 'db.php';
require_once 'includes/header.php';

// Fetch lessons with user progress if logged in
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("
        SELECT l.*, p.quiz_score 
        FROM lessons l 
        LEFT JOIN progress p ON l.id = p.lesson_id AND p.user_id = ?
        ORDER BY l.id ASC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $lessons = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM lessons ORDER BY id ASC");
    $lessons = $stmt->fetchAll();
}
?>

<div class="container">
    <h1 class="mb-4 text-center">Available Lessons</h1>

    <div class="grid">
        <?php foreach ($lessons as $lesson): ?>
            <div class="card">
                <img src="<?php echo htmlspecialchars($lesson['image_url']); ?>" alt="<?php echo htmlspecialchars($lesson['title']); ?>" class="card-img" onerror="this.src='https://via.placeholder.com/600x400?text=Lesson'">
                <div style="padding: 0;">
                    <div style="margin-bottom: 1rem; display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <span style="background: var(--primary-color); color: white; padding: 0.25rem 0.5rem; border-radius: 999px; font-size: 0.75rem; text-transform: uppercase;">
                            <?php echo htmlspecialchars($lesson['difficulty']); ?>
                        </span>
                        <span style="background: #e5e7eb; color: var(--text-color); padding: 0.25rem 0.5rem; border-radius: 999px; font-size: 0.75rem;">
                            <?php echo htmlspecialchars($lesson['category'] ?? 'Other'); ?>
                        </span>
                    </div>
                    <h3><?php echo htmlspecialchars($lesson['title']); ?></h3>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if (isset($lesson['quiz_score'])): ?>
                            <div style="margin-bottom: 1rem;">
                                <div style="display: flex; justify-content: space-between; font-size: 0.8rem; margin-bottom: 0.25rem;">
                                    <span style="color: #059669; font-weight: 600;">Completed</span>
                                    <span>Score: <?php echo $lesson['quiz_score']; ?>%</span>
                                </div>
                                <div style="width: 100%; height: 6px; background: #e5e7eb; border-radius: 999px;">
                                    <div style="width: 100%; height: 100%; background: #059669; border-radius: 999px;"></div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div style="margin-bottom: 1rem; font-size: 0.8rem; color: var(--text-muted);">
                                Not Started
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                        <?php echo htmlspecialchars($lesson['description']); ?>
                    </p>
                    <a href="lesson.php?id=<?php echo $lesson['id']; ?>" class="btn btn-outline btn-block">
                        <?php echo isset($lesson['quiz_score']) ? 'Review Lesson' : 'Start Learning'; ?>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>