<?php
require_once 'db.php';
require_once 'includes/header.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Fetch Progress Stats
// 1. Total Completed Lessons
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT lesson_id) FROM progress WHERE user_id = ?");
$stmt->execute([$user_id]);
$completed_lessons = $stmt->fetchColumn();

// 2. Average Quiz Score
$stmt = $pdo->prepare("SELECT AVG(quiz_score) FROM progress WHERE user_id = ?");
$stmt->execute([$user_id]);
$avg_score = round($stmt->fetchColumn(), 1);

// 3. User Learning Level & Recommendations
// First, ensure we have the latest user data including learning_level
$stmt = $pdo->prepare("SELECT learning_level FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user_data = $stmt->fetch();
$learning_level = $user_data['learning_level'] ?? 'Beginner'; // Default to beginner

// Fetch recommended lessons based on difficulty not yet completed
$stmt = $pdo->prepare("
    SELECT l.* 
    FROM lessons l 
    LEFT JOIN progress p ON l.id = p.lesson_id AND p.user_id = ? 
    WHERE l.difficulty = ? AND p.id IS NULL 
    LIMIT 3
");
$stmt->execute([$user_id, $learning_level]);
$recommended_lessons = $stmt->fetchAll();

// If no recommendations (e.g., all completed or none at level), show popular ones
if (empty($recommended_lessons)) {
    $stmt = $pdo->query("SELECT * FROM lessons LIMIT 3");
    $recommended_lessons = $stmt->fetchAll();
}

// 4. Recent Activity
$stmt = $pdo->prepare("
    SELECT p.quiz_score, p.completed_at, l.title 
    FROM progress p 
    JOIN lessons l ON p.lesson_id = l.id 
    WHERE p.user_id = ? 
    ORDER BY p.completed_at DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$recent_activities = $stmt->fetchAll();

require_once 'includes/functions.php';
$streak = calculateStreak($pdo, $user_id);
$badges = getBadges($pdo, $user_id);
?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <div>
            <h1>Hello, <?php echo htmlspecialchars($user_name); ?>! 👋</h1>
            <p style="color: var(--text-muted);">Current Level: <strong><?php echo htmlspecialchars($learning_level); ?></strong></p>
        </div>
        <a href="lessons.php" class="btn btn-primary">Start New Lesson</a>
    </div>

    <!-- Stats Grid -->
    <div class="grid mb-4">
        <div class="card">
            <h3>Completed Lessons</h3>
            <p style="font-size: 2.5rem; color: var(--primary-color); font-weight: 700;">
                <?php echo $completed_lessons; ?>
            </p>
        </div>
        <div class="card">
            <h3>Average Score</h3>
            <p style="font-size: 2.5rem; color: var(--secondary-color); font-weight: 700;">
                <?php echo $avg_score ? $avg_score . '%' : '-'; ?>
            </p>
        </div>
        <div class="card">
            <h3>Learning Streak</h3>
            <p style="font-size: 2.5rem; color: #F59E0B; font-weight: 700;">
                <?php echo $streak; ?> Days
            </p>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Keep it up!</p>
        </div>
    </div>

    <!-- Recommended for You -->
    <h2 class="mb-4">Recommended path for you</h2>
    <div class="grid mb-4">
        <?php foreach ($recommended_lessons as $lesson): ?>
            <div class="card">
                <img src="<?php echo htmlspecialchars($lesson['image_url']); ?>" alt="<?php echo htmlspecialchars($lesson['title']); ?>" class="card-img" onerror="this.src='https://via.placeholder.com/600x400?text=Lesson'">
                <div style="margin-bottom: 0.5rem;">
                    <span style="background: var(--primary-color); color: white; padding: 0.25rem 0.5rem; border-radius: 999px; font-size: 0.75rem; text-transform: uppercase;">
                        <?php echo htmlspecialchars($lesson['difficulty']); ?>
                    </span>
                </div>
                <h3><?php echo htmlspecialchars($lesson['title']); ?></h3>
                <a href="lesson.php?id=<?php echo $lesson['id']; ?>" class="btn btn-outline btn-block mt-4" style="margin-top: 1rem;">Start Lesson</a>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Recent Activity -->
    <h2 class="mb-4">Recent Activity</h2>
    <?php if (count($recent_activities) > 0): ?>
        <div class="card" style="padding: 0;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead style="background: var(--background-color); border-bottom: 1px solid var(--border-color);">
                    <tr>
                        <th style="text-align: left; padding: 1rem;">Lesson</th>
                        <th style="text-align: right; padding: 1rem;">Score</th>
                        <th style="text-align: right; padding: 1rem;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_activities as $activity): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 1rem;"><?php echo htmlspecialchars($activity['title']); ?></td>
                            <td style="padding: 1rem; text-align: right;">
                                <span style="font-weight: 700; color: <?php echo $activity['quiz_score'] >= 80 ? 'var(--secondary-color)' : 'var(--text-color)'; ?>">
                                    <?php echo $activity['quiz_score']; ?>%
                                </span>
                            </td>
                            <td style="padding: 1rem; text-align: right; color: var(--text-muted);">
                                <?php echo date('M j, Y', strtotime($activity['completed_at'])); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="card text-center" style="padding: 3rem;">
            <p style="color: var(--text-muted); margin-bottom: 1rem;">No activity yet.</p>
            <a href="lessons.php" class="btn btn-outline">Start Learning</a>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>