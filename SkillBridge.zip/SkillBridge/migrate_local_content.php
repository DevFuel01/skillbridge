<?php
require_once 'db.php';

try {
    // Check if lesson exists
    $stmt = $pdo->prepare("SELECT id FROM lessons WHERE title = ?");
    $stmt->execute(['Digital Payments in Africa']);
    if ($stmt->fetch()) {
        die("Lesson already exists.\n");
    }

    // Insert Lesson
    $content = '<h2>Mobile Money: A Digital Revolution</h2>
    <p>In many parts of Africa, mobile phones have changed how people handle money. Instead of traditional banks, many use <strong>Mobile Money</strong> (like M-Pesa, Airtel Money, or MTN MoMo).</p>
    
    <h3>What is Mobile Money?</h3>
    <p>It is a digital wallet stored on your mobile phone. You can use it to store, send, and receive money without needing a bank account.</p>
    
    <h3>Key Benefits</h3>
    <ul>
        <li><strong>Accessibility:</strong> Works on basic "feature phones" using USSD codes (like *123#).</li>
        <li><strong>Safety:</strong> No need to carry large amounts of cash.</li>
        <li><strong>Inclusivity:</strong> Reach people in rural areas where there are no banks.</li>
    </ul>
    
    <h3>Best Practices for Safety</h3>
    <p>Never share your <strong>PIN</strong> with anyone, even if they claim to work for the service provider. Always confirm the recipient\'s name before completing a transaction.</p>';

    $stmt = $pdo->prepare("INSERT INTO lessons (title, description, content, image_url, difficulty, category) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        'Digital Payments in Africa',
        'Learn about mobile money and digital wallets used across the continent.',
        $content,
        'assets/images/mobile-money.jpg',
        'Beginner',
        'Basic Computer Skills'
    ]);

    $lesson_id = $pdo->lastInsertId();

    // Insert Quiz for this lesson
    $quiz_json = '[
        {"question": "What do you need to send mobile money on a basic phone?", "options": ["Internet connection", "USSD codes (like *123#)", "A computer"], "correct": 1},
        {"question": "Who should you share your Mobile Money PIN with?", "options": ["Service provider agents", "Friends", "No one"], "correct": 2},
        {"question": "Is a traditional bank account required for basic mobile money?", "options": ["Yes", "No", "Only for large amounts"], "correct": 1}
    ]';

    $stmt = $pdo->prepare("INSERT INTO quizzes (lesson_id, questions_json) VALUES (?, ?)");
    $stmt->execute([$lesson_id, $quiz_json]);

    echo "Africa-focused lesson and quiz added successfully.\n";
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
