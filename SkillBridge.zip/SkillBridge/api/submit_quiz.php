<?php
require_once '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Unauthorized']));
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['lesson_id']) || !isset($input['score'])) {
    http_response_code(400);
    die(json_encode(['error' => 'Invalid input']));
}

$user_id = $_SESSION['user_id'];
$lesson_id = $input['lesson_id'];
$score = $input['score'];

// Insert or nothing (simple progress tracking for now)
// We'll just insert a new record for every attempt to track history
$stmt = $pdo->prepare("INSERT INTO progress (user_id, lesson_id, quiz_score) VALUES (?, ?, ?)");
if ($stmt->execute([$user_id, $lesson_id, $score])) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
