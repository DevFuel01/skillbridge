-- Create Database
CREATE DATABASE IF NOT EXISTS skillbridge;
USE skillbridge;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    age_range ENUM('Under 18', '18-24', '25-34', '35-44', '45+') DEFAULT '18-24',
    learning_level ENUM('Beginner', 'Intermediate', 'Advanced') DEFAULT 'Beginner',
    role ENUM('student', 'admin') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert Admin User (password: password123)
-- Hash generated using password_hash('password123', PASSWORD_DEFAULT)
INSERT INTO users (name, email, password, role) VALUES 
('Admin User', 'admin@skillbridge.com', '$2y$10$ANmzqSALcf5HhIva./TBHOI0aXJxNODSBQqg6fpCpvZgeG1r/ySJG', 'admin');

-- Lessons Table
CREATE TABLE IF NOT EXISTS lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content LONGTEXT, -- Stores HTML content for the lesson
    image_url VARCHAR(255),
    difficulty ENUM('Beginner', 'Intermediate', 'Advanced') DEFAULT 'Beginner',
    category VARCHAR(255) DEFAULT 'Other',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Quizzes Table
CREATE TABLE IF NOT EXISTS quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT NOT NULL,
    questions_json JSON, -- Storing questions as JSON for flexibility
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);

-- Progress Table
CREATE TABLE IF NOT EXISTS progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    quiz_score INT DEFAULT 0,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);

-- Community Suggestions Table
CREATE TABLE IF NOT EXISTS community_suggestions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    suggestion TEXT NOT NULL,
    status ENUM('pending', 'approved') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Activity Log Table
CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- INSERT SAMPLE DATA --

-- Lessons
INSERT INTO lessons (title, description, content, image_url, difficulty) VALUES 
('Introduction to Web Development', 'Learn the basics of how the web works.', '<h2>What is the Web?</h2><p>The World Wide Web is a system of interconnected documents...</p><h3>HTML, CSS, JS</h3><p>These are the 3 pillars...</p>', 'assets/images/web-dev.jpg', 'Beginner'),
('HTML Basics', 'Structure your web pages with HTML.', '<h2>HTML Tags</h2><p>HTML stands for HyperText Markup Language...</p>', 'assets/images/html.jpg', 'Beginner'),
('CSS Fundamentals', 'Style your pages with CSS.', '<h2>Selectors and Properties</h2><p>CSS allows you to style your HTML...</p>', 'assets/images/css.jpg', 'Beginner');

-- Digital Payments in Africa (Added in latest update)
INSERT INTO lessons (title, description, content, image_url, difficulty, category) VALUES 
('Digital Payments in Africa', 'Learn about mobile money and digital wallets used across the continent.', '<h2>Mobile Money: A Digital Revolution</h2><p>In many parts of Africa, mobile phones have changed how people handle money...</p>', 'assets/images/mobile-money.jpg', 'Beginner', 'Basic Computer Skills');

-- Quizzes (JSON format for questions)
INSERT INTO quizzes (lesson_id, questions_json) VALUES 
(1, '[
    {"question": "What does HTML stand for?", "options": ["HyperText Markup Language", "HighText Machine Learning", "HyperTool Multi Language"], "correct": 0},
    {"question": "Which language is used for styling?", "options": ["HTML", "CSS", "PHP"], "correct": 1}
]'),
(2, '[
    {"question": "Which tag is used for the largest heading?", "options": ["<h6>", "<head>", "<h1>"], "correct": 2}
]'),
(4, '[
    {"question": "What do you need to send mobile money on a basic phone?", "options": ["Internet connection", "USSD codes (like *123#)", "A computer"], "correct": 1},
    {"question": "Who should you share your Mobile Money PIN with?", "options": ["Service provider agents", "Friends", "No one"], "correct": 2},
    {"question": "Is a traditional bank account required for basic mobile money?", "options": ["Yes", "No", "Only for large amounts"], "correct": 1}
]');
