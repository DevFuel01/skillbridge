<?php
require_once 'db.php';

echo "Checking database schema...\n";

// 1. Check/Add 'role' column
try {
    $pdo->query("SELECT role FROM users LIMIT 1");
    echo "Column 'role' already exists.\n";
} catch (PDOException $e) {
    echo "Column 'role' missing. Adding it...\n";
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN role ENUM('student', 'admin') DEFAULT 'student'");
        echo "Successfully added 'role' column.\n";
    } catch (PDOException $e2) {
        die("Failed to add column: " . $e2->getMessage());
    }
}

// 2. Add/Update Admin User
$name = 'Admin User';
$email = 'admin@skillbridge.com';
$password = 'password123';
$role = 'admin';

echo "Setting up admin user ($email)...\n";

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if user exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
$exists = $stmt->fetch();

if ($exists) {
    // Update existing user to be admin with new password
    $stmt = $pdo->prepare("UPDATE users SET password = ?, role = ? WHERE email = ?");
    if ($stmt->execute([$hashed_password, $role, $email])) {
        echo "Admin user updated successfully.\n";
    } else {
        echo "Failed to update admin user.\n";
    }
} else {
    // Insert new admin user
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$name, $email, $hashed_password, $role])) {
        echo "Admin user created successfully.\n";
    } else {
        echo "Failed to create admin user.\n";
    }
}
