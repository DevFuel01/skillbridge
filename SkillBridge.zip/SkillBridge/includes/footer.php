    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> SkillBridge. Empowering learning everywhere.</p>
        </div>
    </footer>
    <!-- Offline Support -->
    <script src="assets/js/app.js"></script>
    </body>

    </html>