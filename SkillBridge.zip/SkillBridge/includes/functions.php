<?php
function calculateStreak($pdo, $user_id)
{
    try {
        // fetch unique dates of activity
        $stmt = $pdo->prepare("
            SELECT DISTINCT DATE(completed_at) as activity_date 
            FROM progress 
            WHERE user_id = ? 
            ORDER BY activity_date DESC
        ");
        $stmt->execute([$user_id]);
        $dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (empty($dates)) return 0;

        $streak = 0;
        $today = new DateTime();
        $today->setTime(0, 0, 0);

        $yesterday = clone $today;
        $yesterday->modify('-1 day');

        // Check if latest activity is today or yesterday to keep streak alive
        $latest = new DateTime($dates[0]);
        $latest->setTime(0, 0, 0);

        if ($latest < $yesterday) {
            return 0; // Streak broken
        }

        // Calculate consecutive days
        $streak = 1;
        $previous_date = $latest;

        for ($i = 1; $i < count($dates); $i++) {
            $current_date = new DateTime($dates[$i]);
            $current_date->setTime(0, 0, 0);

            $diff = $previous_date->diff($current_date)->days;

            if ($diff == 1) {
                $streak++;
                $previous_date = $current_date;
            } else {
                break;
            }
        }
        return $streak;
    } catch (Exception $e) {
        return 0;
    }
}

function getBadges($pdo, $user_id)
{
    $badges = [];

    // Count completed lessons
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT lesson_id) FROM progress WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $completed_count = $stmt->fetchColumn();

    // Streak
    $streak = calculateStreak($pdo, $user_id);

    // Rule 1: Beginner (First Lesson)
    if ($completed_count >= 1) {
        $badges[] = ['name' => 'Beginner', 'icon' => '🌱', 'desc' => 'Completed your first lesson'];
    }

    // Rule 2: Intermediate (5 Lessons)
    if ($completed_count >= 5) {
        $badges[] = ['name' => 'Scholar', 'icon' => '📚', 'desc' => 'Completed 5 lessons'];
    }

    // Rule 3: Dedicated (3 Day Streak)
    if ($streak >= 3) {
        $badges[] = ['name' => 'Dedicated', 'icon' => '🔥', 'desc' => '3-day learning streak'];
    }

    // Rule 4: Master (All lessons - checking slightly loosely)
    // Could add 'Master' if count >= 10 etc.

    return $badges;
}

function log_activity($pdo, $user_id, $action, $details = null)
{
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $details, $ip]);
        return true;
    } catch (Exception $e) {
        // Fail silently to not disrupt the main flow
        return false;
    }
}
