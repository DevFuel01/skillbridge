<?php
require_once 'db.php';

try {
    $tablesStatement = $pdo->query("SHOW TABLES");
    $tables = $tablesStatement->fetchAll(PDO::FETCH_COLUMN);

    foreach ($tables as $table) {
        $createTableStatement = $pdo->query("SHOW CREATE TABLE $table");
        $createTable = $createTableStatement->fetch(PDO::FETCH_ASSOC);
        echo "\n-- Table: $table\n";
        echo $createTable['Create Table'] . ";\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
