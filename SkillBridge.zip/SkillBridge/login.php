<?php
require_once 'db.php';
require_once 'includes/functions.php'; // For logging
require_once 'includes/header.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } else {
        $stmt = $pdo->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Prevent session fixation
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'] ?? 'student';

            log_activity($pdo, $user['id'], 'Login', 'User logged in successfully');

            if ($_SESSION['role'] === 'admin') {
                echo "<script>window.location.href='admin/dashboard.php';</script>";
            } else {
                echo "<script>window.location.href='dashboard.php';</script>";
            }
            exit;
        } else {
            $error = "Invalid email or password.";
            log_activity($pdo, null, 'Login Failure', "Failed login attempt for email: $email");
        }
    }
}
?>

<div class="container" style="max-width: 400px;">
    <div class="card">
        <h2 class="text-center mb-4">Welcome Back</h2>

        <?php if ($error): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required placeholder="john@example.com">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="******">
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="padding: 0.75rem;">Login</button>
        </form>
        <p class="text-center mt-4">
            Don't have an account? <a href="register.php">Register here</a>
        </p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>