<?php
require_once 'db.php';
require_once 'includes/header.php';

if (!isset($_GET['id'])) {
    header("Location: lessons.php");
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM lessons WHERE id = ?");
$stmt->execute([$id]);
$lesson = $stmt->fetch();

if (!$lesson) {
    echo "<div class='container'><h2>Lesson not found.</h2><a href='lessons.php'>Back to Lessons</a></div>";
    require_once 'includes/footer.php';
    exit;
}
?>

<style>
    @media print {

        header,
        footer,
        .btn,
        .back-link,
        .quiz-cta {
            display: none !important;
        }

        body {
            background: white;
            color: black;
        }

        .container {
            max-width: 100%;
            margin: 0;
            padding: 0;
        }

        .card {
            box-shadow: none;
            border: none;
            padding: 0;
        }
    }
</style>

<div class="container" style="max-width: 800px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <a href="lessons.php" class="back-link" style="display: inline-flex; align-items: center; gap: 0.5rem; color: var(--text-muted);">
            &larr; Back to Lessons
        </a>
        <button onclick="window.print()" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Download / Print
        </button>
    </div>

    <img src="<?php echo htmlspecialchars($lesson['image_url']); ?>" alt="Lesson Image" style="width: 100%; max-height: 400px; object-fit: cover; border-radius: var(--radius); margin-bottom: 2rem;" onerror="this.style.display='none'">

    <h1 class="mb-4"><?php echo htmlspecialchars($lesson['title']); ?></h1>

    <div class="card" style="padding: 2rem; line-height: 1.8; font-size: 1.1rem; margin-bottom: 3rem;">
        <?php echo $lesson['content']; ?>
    </div>

    <!-- Quiz CTA -->
    <div class="text-center" style="padding: 2rem; background: var(--card-bg); border-radius: var(--radius); border: 1px solid var(--border-color);">
        <h3 class="mb-4">Mastered this topic?</h3>
        <p class="mb-4 text-muted">Take a quick quiz to test your knowledge and earn points.</p>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="quiz.php?id=<?php echo $id; ?>" class="btn btn-primary" style="padding: 1rem 3rem; font-size: 1.2rem;">Take Quiz</a>
        <?php else: ?>
            <a href="login.php" class="btn btn-primary">Login to Take Quiz</a>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>