<?php
require_once '../db.php';
require_once 'includes/header.php';

// Handle Delete
if (isset($_POST['delete_id'])) {
    $id = $_POST['delete_id'];

    // Prevent deleting self
    if ($id == $_SESSION['user_id']) {
        $error = "You cannot delete your own account.";
    } else {
        // Fetch user email for logging
        $stmt_user = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmt_user->execute([$id]);
        $user_to_delete = $stmt_user->fetch();

        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $msg = "User deleted successfully.";

        log_activity($pdo, $_SESSION['user_id'], 'Deleted User', "Deleted user ID: $id, Email: " . ($user_to_delete['email'] ?? 'Unknown'));
    }
}

// Fetch Users (exclude current admin from delete options visually maybe, or just handle in logic)
$stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h1>Manage Users</h1>
</div>

<?php if (isset($msg)): ?>
    <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
        <?php echo $msg; ?>
    </div>
<?php endif; ?>

<?php if (isset($error)): ?>
    <div style="background: #fee2e2; color: #991b1b; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
        <?php echo $error; ?>
    </div>
<?php endif; ?>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse;">
        <thead style="background: var(--background-color); border-bottom: 1px solid var(--border-color);">
            <tr>
                <th style="text-align: left; padding: 1rem;">ID</th>
                <th style="text-align: left; padding: 1rem;">Name</th>
                <th style="text-align: left; padding: 1rem;">Email</th>
                <th style="text-align: left; padding: 1rem;">Role</th>
                <th style="text-align: right; padding: 1rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 1rem; color: var(--text-muted);">#<?php echo $user['id']; ?></td>
                    <td style="padding: 1rem;">
                        <strong><?php echo htmlspecialchars($user['name']); ?></strong>
                    </td>
                    <td style="padding: 1rem; color: var(--text-muted);">
                        <?php echo htmlspecialchars($user['email']); ?>
                    </td>
                    <td style="padding: 1rem;">
                        <span style="font-size: 0.85rem; padding: 0.25rem 0.5rem; background: <?php echo $user['role'] === 'admin' ? '#fef3c7' : '#e0e7ff'; ?>; color: <?php echo $user['role'] === 'admin' ? '#92400e' : '#3730a3'; ?>; border-radius: 999px;">
                            <?php echo ucfirst(htmlspecialchars($user['role'] ?? 'student')); ?>
                        </span>
                    </td>
                    <td style="padding: 1rem; text-align: right;">
                        <?php if ($user['role'] === 'student'): ?>
                            <a href="user_progress.php?id=<?php echo $user['id']; ?>" class="btn btn-outline" style="padding: 0.25rem 0.5rem; font-size: 0.9rem; margin-right: 0.5rem;">Progress</a>
                        <?php endif; ?>

                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <form method="POST" onsubmit="return confirm('Are you sure? This will delete the user and all their progress.');" style="display: inline;">
                                <input type="hidden" name="delete_id" value="<?php echo $user['id']; ?>">
                                <button type="submit" class="btn btn-primary" style="background-color: #ef4444; border: none; padding: 0.25rem 0.5rem; font-size: 0.9rem;">Delete</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted" style="font-size: 0.9rem;">(You)</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>