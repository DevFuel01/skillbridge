<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once '../includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkillBridge Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Admin specific overrides */
        header {
            background-color: #1e293b;
            color: white;
        }

        .logo,
        .nav-links a {
            color: white !important;
        }

        .nav-links a:hover {
            color: var(--secondary-color) !important;
        }

        .btn-logout {
            border-color: white !important;
            color: white !important;
        }

        .btn-logout:hover {
            background-color: white !important;
            color: #1e293b !important;
        }
    </style>
</head>

<body>
    <header>
        <div class="container navbar">
            <a href="dashboard.php" class="logo">
                SkillBridge Admin
            </a>
            <nav>
                <ul class="nav-links">
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="manage_lessons.php">Lessons</a></li>
                    <li><a href="manage_suggestions.php">Suggestions</a></li>
                    <li><a href="manage_users.php">Users</a></li>
                    <li><a href="activity_logs.php">Logs</a></li>
                    <li><a href="../logout.php" class="btn btn-outline btn-logout" style="padding: 0.25rem 0.75rem; font-size: 0.9rem;">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main class="container">