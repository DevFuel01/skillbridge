<?php
require_once '../db.php';
require_once 'includes/header.php';

if (!isset($_GET['id'])) {
    header("Location: manage_users.php");
    exit;
}

$user_id = $_GET['id'];

// Fetch User
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'student'");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    die("Student not found.");
}

// Fetch all lessons status
$stmt = $pdo->prepare("
    SELECT l.id, l.title, p.quiz_score, p.completed_at 
    FROM lessons l 
    LEFT JOIN progress p ON l.id = p.lesson_id AND p.user_id = ?
    ORDER BY l.id ASC
");
$stmt->execute([$user_id]);
$all_progress = $stmt->fetchAll();

$completed_count = 0;
foreach ($all_progress as $p) if ($p['quiz_score'] !== null) $completed_count++;
$total_lessons = count($all_progress);
$completion_rate = $total_lessons > 0 ? round(($completed_count / $total_lessons) * 100) : 0;

// Fetch full attempt history
$stmt = $pdo->prepare("
    SELECT p.*, l.title 
    FROM progress p 
    JOIN lessons l ON p.lesson_id = l.id 
    WHERE p.user_id = ? 
    ORDER BY p.completed_at DESC
");
$stmt->execute([$user_id]);
$history = $stmt->fetchAll();
?>

<div style="margin-bottom: 2rem;">
    <a href="manage_users.php" style="color: var(--text-muted);">&larr; Back to Users</a>
</div>

<div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="margin-bottom: 0.5rem;">Learner: <?php echo htmlspecialchars($user['name']); ?></h1>
        <p style="color: var(--text-muted);">Email: <?php echo htmlspecialchars($user['email']); ?></p>
        <p style="color: var(--text-muted);">Learning Level: <strong><?php echo htmlspecialchars($user['learning_level']); ?></strong></p>
    </div>

    <div class="card" style="min-width: 200px; text-align: center;">
        <h3 style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 0.5rem;">Overall Progress</h3>
        <p style="font-size: 2.5rem; color: var(--primary-color); font-weight: 700;"><?php echo $completion_rate; ?>%</p>
        <p style="font-size: 0.8rem;"><?php echo $completed_count; ?> of <?php echo $total_lessons; ?> lessons</p>
    </div>
</div>

<div class="grid mb-4">
    <div class="card" style="padding: 0;">
        <div style="padding: 1.5rem; border-bottom: 1px solid var(--border-color);">
            <h3>Lesson Status</h3>
        </div>
        <table style="width: 100%; border-collapse: collapse;">
            <tbody>
                <?php foreach ($all_progress as $p): ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 1rem;"><?php echo htmlspecialchars($p['title']); ?></td>
                        <td style="padding: 1rem; text-align: right;">
                            <?php if ($p['quiz_score'] !== null): ?>
                                <span style="color: #059669; font-weight: 600;">Completed (<?php echo $p['quiz_score']; ?>%)</span>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">Not Started</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card" style="padding: 0;">
        <div style="padding: 1.5rem; border-bottom: 1px solid var(--border-color);">
            <h3>Quiz Attempt History</h3>
        </div>
        <div style="max-height: 400px; overflow-y: auto;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead style="background: var(--background-color); position: sticky; top: 0;">
                    <tr>
                        <th style="text-align: left; padding: 1rem; font-size: 0.8rem;">Lesson</th>
                        <th style="text-align: center; padding: 1rem; font-size: 0.8rem;">Score</th>
                        <th style="text-align: right; padding: 1rem; font-size: 0.8rem;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($history)): ?>
                        <tr>
                            <td colspan="3" style="padding: 2rem; text-align: center; color: var(--text-muted);">No activity recorded yet.</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($history as $h): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 0.75rem 1rem; font-size: 0.9rem;"><?php echo htmlspecialchars($h['title']); ?></td>
                            <td style="padding: 0.75rem 1rem; text-align: center;">
                                <span style="font-weight: 600; color: <?php echo $h['quiz_score'] >= 70 ? '#059669' : '#b91c1c'; ?>;">
                                    <?php echo $h['quiz_score']; ?>%
                                </span>
                            </td>
                            <td style="padding: 0.75rem 1rem; text-align: right; color: var(--text-muted); font-size: 0.8rem;">
                                <?php echo date('M j, Y H:i', strtotime($h['completed_at'])); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>