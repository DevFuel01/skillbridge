<?php
require_once '../db.php';
require_once 'includes/header.php';

$title = $description = $content = $image_url = $difficulty = $category = '';
$quiz_json = '[{"question": "Example Question?", "options": ["Option A", "Option B", "Option C"], "correct": 0}]';
$is_edit = false;

if (isset($_GET['id'])) {
    $is_edit = true;
    $stmt = $pdo->prepare("SELECT * FROM lessons WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $lesson = $stmt->fetch();

    if ($lesson) {
        $title = $lesson['title'];
        $description = $lesson['description'];
        $content = $lesson['content'];
        $image_url = $lesson['image_url'];
        $difficulty = $lesson['difficulty'];
        $category = $lesson['category'];

        // Fetch Quiz
        $stmt_q = $pdo->prepare("SELECT questions_json FROM quizzes WHERE lesson_id = ?");
        $stmt_q->execute([$_GET['id']]);
        $quiz = $stmt_q->fetch();
        if ($quiz) {
            $quiz_json = $quiz['questions_json'];
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $content = $_POST['content'];
    $image_url = $_POST['image_url'];
    $difficulty = $_POST['difficulty'];
    $category = $_POST['category'];
    $quiz_json = $_POST['quiz_json'];

    if ($is_edit) {
        $stmt = $pdo->prepare("UPDATE lessons SET title=?, description=?, content=?, image_url=?, difficulty=?, category=? WHERE id=?");
        $stmt->execute([$title, $description, $content, $image_url, $difficulty, $category, $_GET['id']]);

        log_activity($pdo, $_SESSION['user_id'], 'Updated Lesson', "ID: {$_GET['id']}, Title: $title");

        // Update Quiz
        $stmt_q = $pdo->prepare("SELECT id FROM quizzes WHERE lesson_id = ?");
        $stmt_q->execute([$_GET['id']]);
        if ($stmt_q->fetch()) {
            $stmt_u = $pdo->prepare("UPDATE quizzes SET questions_json = ? WHERE lesson_id = ?");
            $stmt_u->execute([$quiz_json, $_GET['id']]);
        } else {
            $stmt_i = $pdo->prepare("INSERT INTO quizzes (lesson_id, questions_json) VALUES (?, ?)");
            $stmt_i->execute([$_GET['id'], $quiz_json]);
        }
        $msg = "Lesson updated successfully.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO lessons (title, description, content, image_url, difficulty, category) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $content, $image_url, $difficulty, $category]);
        $new_id = $pdo->lastInsertId();

        log_activity($pdo, $_SESSION['user_id'], 'Created Lesson', "ID: $new_id, Title: $title");

        // Insert Quiz
        $stmt_q = $pdo->prepare("INSERT INTO quizzes (lesson_id, questions_json) VALUES (?, ?)");
        $stmt_q->execute([$new_id, $quiz_json]);

        $msg = "Lesson added successfully.";
        // Reset
        $title = $description = $content = $image_url = $difficulty = $category = '';
        $quiz_json = '[{"question": "Example Question?", "options": ["Option A", "Option B", "Option C"], "correct": 0}]';
    }
}
?>

<div class="container" style="max-width: 800px;">
    <div style="margin-bottom: 2rem;">
        <a href="manage_lessons.php" style="color: var(--text-muted);">&larr; Back to Lessons</a>
    </div>

    <h1><?php echo $is_edit ? 'Edit Lesson' : 'Add New Lesson'; ?></h1>

    <?php if (isset($msg)): ?>
        <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="card">
        <div class="form-group">
            <label>Lesson Title</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
            <div class="form-group">
                <label>Category</label>
                <select name="category" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius);">
                    <option value="Basic Computer Skills" <?php if ($category == 'Basic Computer Skills') echo 'selected'; ?>>Basic Computer Skills</option>
                    <option value="Internet & Email Usage" <?php if ($category == 'Internet & Email Usage') echo 'selected'; ?>>Internet & Email Usage</option>
                    <option value="Microsoft Office / Google Docs" <?php if ($category == 'Microsoft Office / Google Docs') echo 'selected'; ?>>Microsoft Office / Google Docs</option>
                    <option value="Online Safety & Digital Etiquette" <?php if ($category == 'Online Safety & Digital Etiquette') echo 'selected'; ?>>Online Safety & Digital Etiquette</option>
                    <option value="Intro to Coding" <?php if ($category == 'Intro to Coding') echo 'selected'; ?>>Intro to Coding</option>
                    <option value="Other" <?php if ($category == 'Other') echo 'selected'; ?>>Other</option>
                </select>
            </div>

            <div class="form-group">
                <label>Difficulty</label>
                <select name="difficulty" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius);">
                    <option value="Beginner" <?php if ($difficulty == 'Beginner') echo 'selected'; ?>>Beginner</option>
                    <option value="Intermediate" <?php if ($difficulty == 'Intermediate') echo 'selected'; ?>>Intermediate</option>
                    <option value="Advanced" <?php if ($difficulty == 'Advanced') echo 'selected'; ?>>Advanced</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Short Description</label>
            <textarea name="description" rows="3" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit;" required><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="form-group">
            <label>Image URL</label>
            <input type="text" name="image_url" value="<?php echo htmlspecialchars($image_url); ?>" placeholder="assets/images/..." required>
        </div>

        <div class="form-group">
            <label>Content (HTML Supported)</label>
            <textarea name="content" rows="10" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: monospace;" required><?php echo htmlspecialchars($content); ?></textarea>
            <small style="color: var(--text-muted);">Use &lt;h2&gt;, &lt;p&gt;, &lt;ul&gt; tags to format content.</small>
        </div>

        <div class="form-group">
            <label>Quiz Configuration (JSON Format)</label>
            <textarea name="quiz_json" rows="8" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: monospace;" required><?php echo htmlspecialchars($quiz_json); ?></textarea>
            <small style="color: var(--text-muted);">JSON array of objects with 'question', 'options' (array), and 'correct' (index 0+).</small>
        </div>

        <button type="submit" class="btn btn-primary btn-block" style="padding: 1rem; font-size: 1.1rem;">
            <?php echo $is_edit ? 'Update Lesson & Quiz' : 'Create Lesson & Quiz'; ?>
        </button>
    </form>
</div>

<?php require_once '../includes/footer.php'; ?>