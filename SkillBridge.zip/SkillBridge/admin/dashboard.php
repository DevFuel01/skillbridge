<?php
require_once '../db.php';
require_once 'includes/header.php';

// Stats
$total_users = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$total_lessons = $pdo->query("SELECT COUNT(*) FROM lessons")->fetchColumn();
$total_completions = $pdo->query("SELECT COUNT(*) FROM progress")->fetchColumn();
$pending_suggestions = $pdo->query("SELECT COUNT(*) FROM community_suggestions WHERE status = 'pending'")->fetchColumn();

// Recent Signups
$stmt = $pdo->query("SELECT name, email, created_at FROM users WHERE role = 'student' ORDER BY created_at DESC LIMIT 5");
$recent_users = $stmt->fetchAll();

// Recent Activity (Quiz completions)
$stmt = $pdo->query("
    SELECT p.quiz_score, p.completed_at, u.name, l.title 
    FROM progress p 
    JOIN users u ON p.user_id = u.id 
    JOIN lessons l ON p.lesson_id = l.id 
    ORDER BY p.completed_at DESC 
    LIMIT 5
");
$recent_activity = $stmt->fetchAll();
?>

<h1 class="mb-4">Admin Dashboard</h1>

<div class="grid mb-4">
    <div class="card">
        <h3>Total Students</h3>
        <p style="font-size: 2.5rem; color: var(--primary-color); font-weight: 700;">
            <?php echo $total_users; ?>
        </p>
    </div>
    <div class="card">
        <h3>Total Lessons</h3>
        <p style="font-size: 2.5rem; color: var(--secondary-color); font-weight: 700;">
            <?php echo $total_lessons; ?>
        </p>
    </div>
    <div class="card">
        <h3>Quiz Completions</h3>
        <p style="font-size: 2.5rem; color: #F59E0B; font-weight: 700;">
            <?php echo $total_completions; ?>
        </p>
    </div>
    <div class="card">
        <h3>Pending Suggestions</h3>
        <p style="font-size: 2.5rem; color: #f59e0b; font-weight: 700;">
            <?php echo $pending_suggestions; ?>
        </p>
    </div>
</div>

<div style="display: flex; gap: 2rem; flex-wrap: wrap;">
    <div class="card" style="flex: 1; min-width: 300px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>Recent Students</h3>
        </div>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <th style="text-align: left; padding: 0.5rem; font-size: 0.8rem;">Name</th>
                    <th style="padding: 0.5rem; text-align: right; font-size: 0.8rem;">Joined</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_users as $user): ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 0.5rem;"><?php echo htmlspecialchars($user['name']); ?></td>
                        <td style="padding: 0.5rem; text-align: right; color: var(--text-muted); font-size: 0.8rem;"><?php echo date('M j', strtotime($user['created_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card" style="flex: 1; min-width: 300px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3>Recent Activity</h3>
        </div>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <th style="text-align: left; padding: 0.5rem; font-size: 0.8rem;">Student</th>
                    <th style="text-align: center; padding: 0.5rem; font-size: 0.8rem;">Score</th>
                    <th style="text-align: right; padding: 0.5rem; font-size: 0.8rem;">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_activity as $act): ?>
                    <tr style="border-bottom: 1px solid var(--border-color);">
                        <td style="padding: 0.5rem; font-size: 0.9rem;">
                            <strong><?php echo htmlspecialchars($act['name']); ?></strong><br>
                            <small class="text-muted"><?php echo htmlspecialchars($act['title']); ?></small>
                        </td>
                        <td style="padding: 0.5rem; text-align: center; font-weight: 600; color: #059669;"><?php echo $act['quiz_score']; ?>%</td>
                        <td style="padding: 0.5rem; text-align: right; color: var(--text-muted); font-size: 0.75rem;"><?php echo date('M j', strtotime($act['completed_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recent_activity)): ?>
                    <tr>
                        <td colspan="3" style="padding: 1rem; text-align: center; color: var(--text-muted);">No activity yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card" style="flex: 1; min-width: 300px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
        <h3>Quick Actions</h3>
        <p class="text-muted mb-4">Manage your platform content.</p>
        <a href="manage_lessons.php" class="btn btn-primary mb-2" style="width: 200px;">Manage Lessons</a>
        <a href="manage_users.php" class="btn btn-outline mb-2" style="width: 200px;">Manage Users</a>
        <a href="manage_suggestions.php" class="btn btn-outline mb-4" style="width: 200px; border-color: #f59e0b; color: #f59e0b;">Manage Suggestions</a>
        <a href="add_lesson.php" class="btn btn-primary" style="width: 200px;">Add New Lesson</a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>