<?php
require_once '../db.php';
require_once 'includes/header.php';

// Handle Delete
if (isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM lessons WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    $msg = "Lesson deleted successfully.";
}

// Fetch Lessons
$stmt = $pdo->query("SELECT * FROM lessons ORDER BY created_at DESC");
$lessons = $stmt->fetchAll();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h1>Manage Lessons</h1>
    <a href="add_lesson.php" class="btn btn-primary">Add New +</a>
</div>

<?php if (isset($msg)): ?>
    <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
        <?php echo $msg; ?>
    </div>
<?php endif; ?>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse;">
        <thead style="background: var(--background-color); border-bottom: 1px solid var(--border-color);">
            <tr>
                <th style="text-align: left; padding: 1rem;">ID</th>
                <th style="text-align: left; padding: 1rem;">Title</th>
                <th style="text-align: left; padding: 1rem;">Category</th>
                <th style="text-align: left; padding: 1rem;">Difficulty</th>
                <th style="text-align: right; padding: 1rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lessons as $lesson): ?>
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 1rem; color: var(--text-muted);">#<?php echo $lesson['id']; ?></td>
                    <td style="padding: 1rem;">
                        <strong><?php echo htmlspecialchars($lesson['title']); ?></strong>
                    </td>
                    <td style="padding: 1rem; color: var(--text-muted);">
                        <?php echo htmlspecialchars($lesson['category'] ?? 'Other'); ?>
                    </td>
                    <td style="padding: 1rem;">
                        <span style="font-size: 0.85rem; padding: 0.25rem 0.5rem; background: #e0e7ff; color: #3730a3; border-radius: 999px;">
                            <?php echo htmlspecialchars($lesson['difficulty']); ?>
                        </span>
                    </td>
                    <td style="padding: 1rem; text-align: right;">
                        <div style="display: flex; gap: 0.5rem; justify-content: flex-end;">
                            <a href="add_lesson.php?id=<?php echo $lesson['id']; ?>" class="btn btn-outline" style="padding: 0.25rem 0.5rem; font-size: 0.9rem;">Edit</a>
                            <form method="POST" onsubmit="return confirm('Are you sure? This will delete all student progress for this lesson.');">
                                <input type="hidden" name="delete_id" value="<?php echo $lesson['id']; ?>">
                                <button type="submit" class="btn btn-primary" style="background-color: #ef4444; border: none; padding: 0.25rem 0.5rem; font-size: 0.9rem;">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>