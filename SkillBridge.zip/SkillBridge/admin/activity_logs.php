<?php
require_once '../db.php';
require_once 'includes/header.php';

// Fetch logs with user names
$stmt = $pdo->query("
    SELECT l.*, u.name as user_name, u.email as user_email 
    FROM activity_log l 
    LEFT JOIN users u ON l.user_id = u.id 
    ORDER BY l.created_at DESC 
    LIMIT 100
");
$logs = $stmt->fetchAll();
?>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h2 style="margin-bottom: 0;">System Activity Logs</h2>
        <span style="color: var(--text-muted); font-size: 0.9rem;">Showing last 100 entries</span>
    </div>

    <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
            <thead>
                <tr style="border-bottom: 2px solid var(--border-color); text-align: left;">
                    <th style="padding: 1rem;">Timestamp</th>
                    <th style="padding: 1rem;">User</th>
                    <th style="padding: 1rem;">Action</th>
                    <th style="padding: 1rem;">Details</th>
                    <th style="padding: 1rem;">IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="5" style="padding: 2rem; text-align: center; color: var(--text-muted);">No activity logs found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 1rem; white-space: nowrap;"><?php echo date('M d, H:i:s', strtotime($log['created_at'])); ?></td>
                            <td style="padding: 1rem;">
                                <?php if ($log['user_name']): ?>
                                    <strong><?php echo htmlspecialchars($log['user_name']); ?></strong><br>
                                    <small style="color: var(--text-muted);"><?php echo htmlspecialchars($log['user_email']); ?></small>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">Guest / System</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 1rem;">
                                <span style="display: inline-block; padding: 0.25rem 0.5rem; border-radius: 999px; font-size: 0.8rem; font-weight: 600; 
                                    <?php
                                    if (strpos($log['action'], 'Failure') !== false) echo 'background: #fee2e2; color: #991b1b;';
                                    elseif ($log['action'] == 'Registration') echo 'background: #dcfce7; color: #166534;';
                                    else echo 'background: #e0f2fe; color: #075985;';
                                    ?>">
                                    <?php echo htmlspecialchars($log['action']); ?>
                                </span>
                            </td>
                            <td style="padding: 1rem;"><?php echo htmlspecialchars($log['details']); ?></td>
                            <td style="padding: 1rem; font-family: monospace; font-size: 0.8rem;"><?php echo htmlspecialchars($log['ip_address']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>