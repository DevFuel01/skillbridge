<?php
require_once '../db.php';
require_once 'includes/header.php';
require_once '../includes/functions.php'; // Assuming log_activity is in functions.php

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && isset($_POST['id'])) {
    $id = $_POST['id'];
    if ($_POST['action'] === 'approve') {
        $stmt = $pdo->prepare("UPDATE community_suggestions SET status = 'approved' WHERE id = ?");
        $stmt->execute([$id]);
        log_activity($pdo, $_SESSION['user_id'], 'Approved Suggestion', "Approved suggestion ID: $id");
        $msg = "Suggestion approved!";
    } elseif ($_POST['action'] === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM community_suggestions WHERE id = ?");
        $stmt->execute([$id]);
        log_activity($pdo, $_SESSION['user_id'], 'Deleted Suggestion', "Deleted suggestion ID: $id");
        $msg = "Suggestion deleted!";
    }
}

// Fetch Suggestions
$stmt = $pdo->query("
    SELECT s.*, u.name, u.email 
    FROM community_suggestions s 
    JOIN users u ON s.user_id = u.id 
    ORDER BY s.created_at DESC
");
$suggestions = $stmt->fetchAll();
?>

<div style="margin-bottom: 2rem;">
    <a href="dashboard.php" style="color: var(--text-muted);">&larr; Back to Dashboard</a>
</div>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h1>Manage Suggestions</h1>
</div>

<?php if (isset($msg)): ?>
    <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
        <?php echo $msg; ?>
    </div>
<?php endif; ?>

<div class="card" style="padding: 0;">
    <table style="width: 100%; border-collapse: collapse;">
        <thead style="background: var(--background-color); border-bottom: 1px solid var(--border-color);">
            <tr>
                <th style="text-align: left; padding: 1rem;">User</th>
                <th style="text-align: left; padding: 1rem;">Suggestion</th>
                <th style="text-align: center; padding: 1rem;">Status</th>
                <th style="text-align: right; padding: 1rem;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($suggestions)): ?>
                <tr>
                    <td colspan="4" style="padding: 2rem; text-align: center; color: var(--text-muted);">No suggestions submitted yet.</td>
                </tr>
            <?php endif; ?>
            <?php foreach ($suggestions as $s): ?>
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 1rem;">
                        <strong><?php echo htmlspecialchars($s['name']); ?></strong><br>
                        <small class="text-muted"><?php echo htmlspecialchars($s['email']); ?></small>
                    </td>
                    <td style="padding: 1rem; max-width: 400px;">
                        <?php echo htmlspecialchars($s['suggestion']); ?>
                    </td>
                    <td style="padding: 1rem; text-align: center;">
                        <span style="font-size: 0.8rem; padding: 0.2rem 0.6rem; border-radius: 999px; background: <?php echo $s['status'] == 'approved' ? '#d1fae5' : '#fef3c7'; ?>; color: <?php echo $s['status'] == 'approved' ? '#065f46' : '#92400e'; ?>;">
                            <?php echo ucfirst($s['status']); ?>
                        </span>
                    </td>
                    <td style="padding: 1rem; text-align: right;">
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                            <?php if ($s['status'] == 'pending'): ?>
                                <button type="submit" name="approve" class="btn" style="background: #10b981; color: white; padding: 0.25rem 0.5rem; font-size: 0.85rem; border: none; cursor: pointer; border-radius: 4px; margin-right: 0.5rem;">Approve</button>
                            <?php endif; ?>
                            <button type="submit" name="delete" class="btn" style="background: #ef4444; color: white; padding: 0.25rem 0.5rem; font-size: 0.85rem; border: none; cursor: pointer; border-radius: 4px;" onclick="return confirm('Delete this suggestion?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>