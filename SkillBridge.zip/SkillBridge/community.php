<?php
require_once 'db.php';
require_once 'includes/header.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $suggestion = trim($_POST['suggestion']);
    if (!empty($suggestion)) {
        $stmt = $pdo->prepare("INSERT INTO community_suggestions (user_id, suggestion) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $suggestion]);
        $msg = "Thank you! Your suggestion has been submitted for review.";
    }
}
?>

<div class="container">
    <div style="text-align: center; margin-bottom: 3rem;">
        <h1>Community Learning Support 🤝</h1>
        <p style="color: var(--text-muted); max-width: 600px; margin: 0 auto;">Connect with other learners, get tips, and help us improve SkillBridge by suggesting new topics.</p>
    </div>

    <?php if ($msg): ?>
        <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: var(--radius); margin-bottom: 2rem; text-align: center;">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-bottom: 4rem;">
        <!-- FAQ Section -->
        <div>
            <h2 class="mb-4">Frequently Asked Questions</h2>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <details style="background: white; border: 1px solid var(--border-color); border-radius: var(--radius); padding: 1rem;">
                    <summary style="font-weight: 600; cursor: pointer;">How do I track my progress?</summary>
                    <p style="margin-top: 1rem; color: var(--text-muted);">You can track your progress on your personal Dashboard. It shows completed lessons, quiz scores, and your learning streak.</p>
                </details>
                <details style="background: white; border: 1px solid var(--border-color); border-radius: var(--radius); padding: 1rem;">
                    <summary style="font-weight: 600; cursor: pointer;">Can I retake quizzes?</summary>
                    <p style="margin-top: 1rem; color: var(--text-muted);">Yes! You can retake any quiz multiple times to improve your score. We always keep track of your latest attempt.</p>
                </details>
                <details style="background: white; border: 1px solid var(--border-color); border-radius: var(--radius); padding: 1rem;">
                    <summary style="font-weight: 600; cursor: pointer;">Is SkillBridge free to use?</summary>
                    <p style="margin-top: 1rem; color: var(--text-muted);">SkillBridge is a completely free platform designed to bridge the digital divide and help everyone gain essential computer skills.</p>
                </details>
            </div>
        </div>

        <!-- Suggestion Section -->
        <div class="card">
            <h2 class="mb-4">Share Your Ideas</h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Is there a topic you'd like to learn about that we haven't covered yet? Tell us!</p>

            <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST">
                    <div class="form-group">
                        <label>Your Suggestion</label>
                        <textarea name="suggestion" rows="4" placeholder="I would like to learn more about..." style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius); font-family: inherit;" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Submit Suggestion</button>
                </form>
            <?php else: ?>
                <div style="text-align: center; padding: 2rem; border: 2px dashed var(--border-color); border-radius: var(--radius);">
                    <p style="margin-bottom: 1rem;">Please log in to submit a suggestion.</p>
                    <a href="login.php" class="btn btn-outline">Log In</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <h2 class="mb-4 text-center">Digital Literacy Tips 💡</h2>
    <div class="grid">
        <div class="card" style="border-top: 4px solid var(--primary-color);">
            <h3>Did You Know?</h3>
            <p style="color: var(--text-muted); font-size: 0.95rem;">You can use <strong>Ctrl + F</strong> on your keyboard to instantly search for any word on a webpage. This saves huge amounts of time!</p>
        </div>
        <div class="card" style="border-top: 4px solid var(--secondary-color);">
            <h3>Password Safety</h3>
            <p style="color: var(--text-muted); font-size: 0.95rem;">A strong password should have at least 12 characters and include a mix of uppercase, lowercase, numbers, and symbols.</p>
        </div>
        <div class="card" style="border-top: 4px solid #10b981;">
            <h3>Best Practices</h3>
            <p style="color: var(--text-muted); font-size: 0.95rem;">Always verify the sender's email address before clicking links in emails, even if they look like they're from your bank or a friend.</p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>