<?php
require_once 'db.php';

try {
    echo "Starting migration...<br>";

    // Add age_range column
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'age_range'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN age_range ENUM('Under 18', '18-24', '25-34', '35-44', '45+') DEFAULT '18-24' AFTER password");
        echo "Added 'age_range' column.<br>";
    } else {
        echo "'age_range' column already exists.<br>";
    }

    // Add learning_level column
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'learning_level'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN learning_level ENUM('Beginner', 'Intermediate', 'Advanced') DEFAULT 'Beginner' AFTER age_range");
        echo "Added 'learning_level' column.<br>";
    } else {
        echo "'learning_level' column already exists.<br>";
    }

    echo "Migration completed successfully.";
} catch (PDOException $e) {
    die("Migration failed: " . $e->getMessage());
}
